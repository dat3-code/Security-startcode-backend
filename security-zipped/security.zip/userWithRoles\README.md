## About this package

This package contains everything related to UserWithRoles, which is a class that extends the User class from Spring Security.

It includes an entity package, as you are used to, but all the rest (DTO's, Controller and Repositories) are in the same package.
